import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child7',
  template: `
    <p>
      child7 works!
    </p>
  `,
  styles: [
  ]
})
export class Child7Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
