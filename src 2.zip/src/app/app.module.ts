import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { PrefixPipe } from 'src/pipe/prefix.pipe';

import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { SuffixPipe } from './suffix.pipe';
import { Child2Component } from './child2/child2.component';
import { Child3Component } from './child2/child3/child3.component';
import { Child5Component } from './child5/child5.component';
import { Child6Component } from './child6/child6.component';
import { Child7Component } from './child7.component';

@NgModule({
  declarations: [
    AppComponent, PrefixPipe, SuffixPipe, ChildComponent, Child2Component, Child3Component, Child5Component, Child6Component, Child7Component
  ],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
