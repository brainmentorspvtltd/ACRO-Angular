import { Component, NgModule } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
 
})
export class AppComponent {
  productId :number;
  doj:Date;
  salary:number;
  myName:string ;
  fruits :string [] = ["Apple", "Orange", "Mango"];
  title = 'My First Application...';
  firstName = "AmIt";
  lastName = "SrivastAvA";
  isDisabled:boolean = true;
  myClass:string = "green";
  count:number =0;
  message:string = "";
  addressValue:string = "";
  remarks:string = "";
  emp:{id:number, name:string, salary:number};
  constructor(){
    this.productId = 1001;
    this.doj = new Date();
    this.emp = {id:1001, name:'Ramesh', salary: 77777};
    this.myName = "Amit Srivastava";
    this.salary = 9876521.3431244;
  }
  plusIt():void{
      this.count++;
  }
  takeInput(event:any):void{
    console.log("Take Input call.... ", event.target.value);
    this.message = event.target.value;
  }
  save(city:string, country:string):void{
    this.addressValue = `City ${city} and Country ${country}`;
  }
}
