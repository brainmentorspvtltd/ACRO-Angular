import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child6',
  template: `
    <p>
      child6 works!
    </p>
  `,
  styles: [
  ]
})
export class Child6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
