import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child5',
  template: `
    <p>
      child5 works!
    </p>
  `,
  styles: [
  ]
})
export class Child5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
