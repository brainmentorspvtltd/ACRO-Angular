import { Pipe, PipeTransform } from "@angular/core";
@Pipe({name:'prefix'})
export class PrefixPipe implements PipeTransform{
    transform(value: any, ...args: any[]) {
        if(args && args.length==2){
        return args[0] +" - "+ value+" - "+args[1]; // SR + ID
        }
        else if (args && args.length ==1){
            return args[0] +" - "+ value;
        }
        else{
            return value;
        }
    }
}