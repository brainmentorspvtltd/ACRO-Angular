// DOM - Document Object Model (Input /Output )
import {TASK_OPERATIONS} from '../data/services/task-operations.js';
window.addEventListener('load', init);

function init(){
    bindEvents();
    showCount();
    disableButtons();
}

function disableButtons(){
    document.querySelector('#remove').setAttribute('disabled', true);
    document.querySelector('#update').setAttribute('disabled', true);
}

 function bindEvents(){
    // Register an Event
    document.getElementById('add').addEventListener('click', addTask);
    document.querySelector('#remove').addEventListener('click', deleteForever);
    document.querySelector('#save').addEventListener('click', save);
    document.querySelector('#load').addEventListener('click', load);
}

function save(){
    if(window.localStorage){
        const tasks = TASK_OPERATIONS.getTasks();
        localStorage.tasks = JSON.stringify(tasks); // Serialization
        // Object to JSON String Convert - Serialization
        alert("Data Store....");
    }
    else{
        alert("Outdated Browser No Support of localstorage....")
    }
}

function load(){
    if(window.localStorage){
        if(localStorage.tasks){
            const tasks = JSON.parse(localStorage.tasks); // Deserialzation
            printTaskTable(tasks);
            showCount();
        }
        else{
            alert("No Data to Load...");
        }
    }
    else{
        alert("Outdated Browser No Support of localstorage....")
    }
}

function deleteForever(){
    const tasks = TASK_OPERATIONS.remove();
    printTaskTable(tasks);
    showCount();

}

function printTaskTable(tasks){
    document.querySelector('#tasks').innerHTML = '';
    //tasks.forEach(taskObject=>printTask(taskObject));
    tasks.forEach(printTask);
}

 function addTask(){
    //console.log('Add Task Call');
    // let id = document.querySelector('#id').value;
    const fields = ['id', 'name', 'desc','date', 'color', 'url'];
    const taskObject = {}; // Object Literal
    for(let field of fields){
        let fieldValue = document.querySelector(`#${field}`).value;
        taskObject[field] = fieldValue;
    }
    TASK_OPERATIONS.add(taskObject);
    console.log('Task Object ', taskObject);
    printTask(taskObject);
    showCount();
}

function edit(){

}
function toggleDelete(){
    // this hold current calling object reference
    console.log('Toggle Delete   ', this);
    let icon = this;
    const tr = icon.parentNode.parentNode;
    const taskId = icon.getAttribute('task-id');
    TASK_OPERATIONS.toggleMark(taskId);
    //tr.className = 'alert-danger';
    tr.classList.toggle('alert-danger');
    showCount();
    const enabledOrDisabled = TASK_OPERATIONS.getMarkCount()>0?false:true;
    document.querySelector('#remove').disabled = enabledOrDisabled;
}

function createIcon(className, fn, taskId){
    //  <i class="fa-solid fa-pen"></i>
    // <i class="fa-solid fa-trash-can"></i>
    const iconTag = document.createElement('i'); //<i></i>
    iconTag.className = `fa-solid ${className} me-2 hand`;
    iconTag.addEventListener('click', fn);
    iconTag.setAttribute('task-id', taskId);
    return iconTag;

}
// This function is used to print a Single Task
function printTask(taskObject){
    const tbody = document.querySelector('#tasks');
    const tr = tbody.insertRow();
    for(let key in taskObject){
        if(key === 'isMarked'){
            continue; // Skip the current Iteration
        }
        let td = tr.insertCell();
        td.innerText = taskObject[key];
    }
    let td = tr.insertCell();
    td.appendChild(createIcon('fa-pen', edit, taskObject.id));
    td.appendChild(createIcon('fa-trash-can', toggleDelete, taskObject.id));
}

function showCount(){
    document.querySelector('#total').innerText = TASK_OPERATIONS.getSize();
    document.querySelector('#mark').innerText = TASK_OPERATIONS.getMarkCount();
    document.querySelector('#unmark').innerText = TASK_OPERATIONS.getUnMarkCount();
}