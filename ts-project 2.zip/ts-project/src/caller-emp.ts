import Employee from "./employee.js";
import { show, MAX } from "./employee.js";

// Has a (Object Create)
var ram:Employee = new Employee("Ram",1010,9999);
//ram.id = 1002;
ram.printEmp();