// Game 
// What to Do
// 100% Abstract
interface IPlayer{
    kick():void; // Bodyless / What to Do
    punch():void;
}

interface Flexi{
    specialKicks():void;
}
interface Hybrid extends IPlayer, Flexi{

}
// How to Do
class Ryu implements Hybrid{
    specialKicks(): void {
        throw new Error("Method not implemented.");
    }
    kick(): void {
        console.log("Kick Taking Lot of Power Logic...");    
    }
    punch(): void {
        console.log("Punch Logic...");
    }
}

class Ken implements IPlayer{
    kick(): void {
        console.log("Kick Logic...");    
    }
    punch(): void {
        console.log("Punch Taking lot of Power Logic...");
    }
}

// Polymorphic Function
function executePlayer(player:IPlayer){
    player.kick();
    player.punch();
}

executePlayer(new Ryu());
executePlayer(new Ken());

// What to do
interface CrudOperations{
    add(arg:Object):boolean;
    read(): Object[];
}

class ApiClient implements CrudOperations{
    add(arg: Object): boolean {
        return false;
    }
    read(): Object[] {
        return [];
    }
    
}

class LocalStorage implements CrudOperations{
    add(arg: Object): boolean {
       return false;
    }
    read(): Object[] {
        return [];
    }
    
}

