import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = '';
  sysDate:Date = new Date();
  amount:number = 987722;
  constructor(){
    this.title = $localize `Hi Angular`;
  }
  
}
