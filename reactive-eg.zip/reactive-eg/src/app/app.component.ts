import { Component } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'reactive-demo';
  promiseData:string = "";
  obsData:string = "";
  count:number = 0;
  count2:number = 0;
  getObs():Observable<string>{
      const obs = new Observable<string>((observer)=>{
        setInterval(()=>{
            this.count ++;
            observer.next("I am the Observer Next Data "+this.count);
        },1000);
      })
      return obs;
  }

  consumeObs():void{
    this.getObs().subscribe(data=>this.obsData = data);
  }

  consumePromise():void{
    this.getPromise().then(data=>{

        this.promiseData = data;
    }).catch(err=>this.promiseData = err);
  }

  getPromise(): Promise<string>{
    const promise = new Promise<string>((resolve, reject)=>{
        setInterval(()=>{
          this.count2++;
          resolve("Success Result "+this.count2);
        }, 1000);
    });
    return promise;
  }
}
