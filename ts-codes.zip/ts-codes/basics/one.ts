var a:number = 100;
var b: number = 200;
var c:number = a + b;
console.log('Sum is ', c);