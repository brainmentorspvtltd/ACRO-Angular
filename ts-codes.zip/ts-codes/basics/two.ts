function add(a:number, b:number):number{
    return a + b;
}
var c:number = add(10,20);
console.log('Sum is ',c);