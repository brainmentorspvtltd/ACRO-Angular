// Type Annotations with Basic Types
var ename:string = "Amit";
var age:number = 22;
var salary:number = 9900.22;
var hex:number = 0xaf9;
var bin:number = 0b101010;
var oct:number = 0o765;
var time:bigint = 1000000000n;
var novalue:undefined = undefined;
var nothing:null = null;
var att:boolean= true;
var f:any  = 100;
f = "Amit";
f = true;
f = JSON.parse('false');

console.log(typeof f);
//f = JSON.parse('1000');
var num:number = JSON.parse('1000');
console.log(typeof num);


// Type Inference
var a = 100;
var b = "Amit";
var c = true;
var d = 1000n;