var firstName:string; // Type Annotation
//firstName = "Amit";
//firstName = 100;
var lastName = "Srivastava"; // Type Inference
console.log(typeof lastName);
//lastName = 100;

// Type Inference in Function
function show(x:number , y:number){
    console.log("I am the Show ", (x+y));
}

// Type Annotation in Function
function show2(x:number , y:number):number{
    console.log("I am the Show ", (x+y));
    return x + y;
}
