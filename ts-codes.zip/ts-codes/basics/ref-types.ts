var d:Date = new Date();
console.log(d);
console.log(typeof d, d instanceof Date );
// Array
var names:string[] = ["amit","ram","shyam","tim"];
var ages:number[] = [10,20,30,40,50];
// Custom Class
class Employee{

}
// Custom Class Object
var ram:Employee = new Employee();

// Object Literal 
var obj:{name:string, age:number} = {name:'Amit', age:21};


// Function as a Type
const add:(x:number, y:number)=>void = (a:number, y:number)=>console.log(a+y);