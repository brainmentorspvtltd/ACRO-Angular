window.addEventListener('load', bindEvents);
function bindEvents():void{ 
    var buttons:NodeListOf<HTMLButtonElement> =  document.querySelectorAll('button');
    buttons.forEach((button:HTMLButtonElement)=>button.addEventListener('click',printValue));
    document.querySelector('#equal')?.removeEventListener('click', printValue);
    document.querySelector('#equal')?.addEventListener('click', compute);
}

function compute():void{
    var txtBox:HTMLInputElement|null = document.querySelector('#output');
    var expression:string|undefined = txtBox?.value;
    if(expression){
        if(txtBox){
        txtBox.value = eval(expression);
        }
    }
}

function printValue():void{
    var currentButton:HTMLButtonElement = this;
    var txtBox:HTMLInputElement|null = document.querySelector('#output');
    if(txtBox!=null){
        txtBox.value += currentButton.innerText;
    }
    
}
