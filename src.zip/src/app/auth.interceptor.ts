import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, Observable, tap } from "rxjs";

@Injectable()
export class AuthInterceptor implements HttpInterceptor{
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
       const cloneReq = req.clone({
        // Cookie Based (Http Only Cookie)
            withCredentials:true, // Attach Cookie in request
        // Token
        headers: req.headers.set('token', 'MYTOKEN').set('Authorization','Bearer'+localStorage.getItem('mytoken'))
        //headers:req.headers.set('Cache-Control','no-cache').set('Pragma','no-cache')
       });
       console.log('Interceptor Get Call');
       
       const obs = next.handle(cloneReq);
       obs.pipe(tap(event=>{
        console.log('Event Rec ', event);
        if(event instanceof HttpResponse){
            if(event.body && event.body.success){
                console.log(event.body.success.message);
                console.log(event.headers);
            }
        }
       })
       //,catchError(err=>{

    //    })
    );
    return obs;

    }

}