import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit, OnDestroy {
  id:number ;
  price:number ;
  declare parameterSub:Subscription;
  // Consume the parameters
  constructor(private params: ActivatedRoute) { 
    this.id = 0;
    this.price = 0;
    
  }
  ngOnDestroy(): void {
      this.parameterSub.unsubscribe();
  }

  ngOnInit(): void {
    if(this.params && this.params.snapshot){
    this.id = this.params.snapshot.params['id'];
    this.price = this.params.snapshot.params['price'];

    this.parameterSub = this.params.params.subscribe({
      next:(allParams)=>{
        this.id = allParams['id'];
        this.price = allParams['price'];
      },
      error:(err)=>console.log('Param Error ', err)
    });
  }
  }

}
