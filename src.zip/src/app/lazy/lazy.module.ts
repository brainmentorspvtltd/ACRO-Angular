import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClothesComponent } from './clothes/clothes.component';
import { MobileComponent } from './mobile/mobile.component';



@NgModule({
  declarations: [
    ClothesComponent,
    MobileComponent
  ],
  imports: [
    CommonModule
  ]
})
export class LazyModule { }
