import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { ShopComponent } from '../shop/shop.component';
import { AboutComponent } from '../about/about.component';
import { NewsComponent } from '../news/news.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { SportsComponent } from '../news/sports/sports.component';
import { BusinessComponent } from '../news/business/business.component';
import { AuthGuard } from '../guards/auth-guard.service';

// Maintain Routes (Mapping)
const applicationRoutes :Routes = [
  {path:'', component : HomeComponent},
  {path:'products/:id/:price', component: ShopComponent, canActivate:[AuthGuard], pathMatch:'full'},
  // Lazy Module
  {path:'products', component: ShopComponent, loadChildren:()=>import('../lazy/lazy.module').then(mod => mod.LazyModule), canActivate:[AuthGuard]},
  // Pre Load Module
  {path:'products2', component: ShopComponent, data:{applyPreload:true},loadChildren:()=>import('../lazy/lazy.module').then(mod => mod.LazyModule), canActivate:[AuthGuard]},
  {path:'about', component:AboutComponent, canActivate:[AuthGuard]},
  {path:'news', component:NewsComponent, children:[
    {path:'sports', component: SportsComponent},
    {path:'business',component:BusinessComponent}
  ]},
  {path:'page-not-found',component:PageNotFoundComponent},
  {path:'**', redirectTo:'page-not-found'}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule, RouterModule.forRoot(applicationRoutes)
  ],
  exports:[RouterModule]
})
export class SpaModule { }
