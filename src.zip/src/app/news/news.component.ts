import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  id:number = 77777;
  constructor(private router:Router) { }
  moveToHome(){
   // this.router.navigate(['/']); // Navigate to Home
   this.router.navigate(['/products/1002/'+this.id]);
  }
  ngOnInit(): void {
  }

}
