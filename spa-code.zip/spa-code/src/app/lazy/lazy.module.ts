import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClothesComponent } from './clothes/clothes.component';
import { MobileComponent } from './mobile/mobile.component';
import { RouterModule, Routes } from '@angular/router';

const applicationRoutes :Routes = [
  {path:'clothes', component : ClothesComponent},
  {path:'mobiles',component:MobileComponent}
];


@NgModule({
  declarations: [
    ClothesComponent,
    MobileComponent
  ],
  imports: [
    CommonModule, RouterModule.forRoot(applicationRoutes)
  ]
})
export class LazyModule { }
