import { Directive, ElementRef, HostListener, Input, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appColorChange]'
})
export class ColorChangeDirective  implements OnInit{
@Input() appColorChange:string = "";
  constructor(private elementRef:ElementRef, private renderer : Renderer2 ) {

    console.log('AppColor Value Rec ', this.appColorChange);
    //this.elementRef.nativeElement.style.backgroundColor = 'green';
    
  }
  ngOnInit(): void {
    console.log('AppColor Value Rec ', this.appColorChange);
    this.renderer.setStyle(this.elementRef.nativeElement,'backgroundColor',this.appColorChange);
  }

  

  @HostListener('mouseover')
  onMouseOver(){
    this.renderer.setStyle(this.elementRef.nativeElement,'backgroundColor','yellow');
  }
  @HostListener('click')
  onMouseClick(){
    this.renderer.setStyle(this.elementRef.nativeElement,'backgroundColor','cyan');
  }

}
