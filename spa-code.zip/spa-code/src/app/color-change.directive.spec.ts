import { ColorChangeDirective } from './color-change.directive';

describe('ColorChangeDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorChangeDirective();
    expect(directive).toBeTruthy();
  });
});
