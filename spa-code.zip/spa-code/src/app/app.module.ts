import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ShopComponent } from './shop/shop.component';
import { AboutComponent } from './about/about.component';
import { NewsComponent } from './news/news.component';
import {RouterModule, Routes} from '@angular/router';
import { MenuComponent } from './widgets/menu/menu.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SpaModule } from './spa/spa.module';
import { SportsComponent } from './news/sports/sports.component';
import { BusinessComponent } from './news/business/business.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ColorChangeDirective } from './color-change.directive';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ShopComponent,
    AboutComponent,
    NewsComponent,
    MenuComponent,
    PageNotFoundComponent,
    SportsComponent,
    BusinessComponent,
    ColorChangeDirective
  ],
  imports: [
    BrowserModule, SpaModule, FormsModule , ReactiveFormsModule, HttpClientModule // Eager Load
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
