import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business',
  templateUrl: './business.component.html',
  styleUrls: ['./business.component.css']
})
export class BusinessComponent implements OnInit {
  fileName:string ;

  progress:any;

  getFileInfo(event:any):void{
      const file:File = event.target.files[0];
      if(file){
          this.fileName = file.name;
          const formData = new FormData();
          formData.append('photo', file);
          const URL:string = "/uploadURL";
          const obs  = this.http.post(URL, formData, {
            reportProgress : true,
            observe : 'events'
          });
          obs.subscribe({
            next: (event)=>{
              if(event.type == HttpEventType.UploadProgress){
                  this.progress =  Math.round((event.loaded / event.total!) * 100);
              }
            }
          })
      }
  }

  constructor(private http:HttpClient) {
    this.fileName = "";
   }

  ngOnInit(): void {
  }

}
