import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.css']
})
export class SportsComponent implements OnInit {
  // Build a Form Model
  // to build form model a) FormGroup, FormBuilder, FormControl, FormArray

  declare regForm:FormGroup;
 
  constructor(private fb:FormBuilder) {
      this.buildFormModel();
   }
   register(){
      console.log('Register Call ',this.regForm);
   }
   addPhone(){
          const fieldArr = this.regForm.get('phone') as FormArray;
          fieldArr.push(new FormControl('', [Validators.required]));
  }

  removePhone(i:number){
    const fieldArr = this.regForm.get('phone') as FormArray;
    fieldArr.removeAt(i);
  }

  get phones():FormArray{
    return  this.regForm.get('phone') as FormArray;
  }

  // Adding custom validations

  checkEmail(control:FormControl):{[key:string]:boolean}|null{
    if(control.value==='tim@yahoo.com'){
      return {'notallowed':true};
    }
    return null;
  }


   buildFormModel():void{
      this.regForm = this.fb.group({
        name:['', [Validators.required, Validators.pattern('[a-z]{3,10}')]],
        email:['', [Validators.required, Validators.email, this.checkEmail.bind(this)]],
        password:['',[Validators.required, Validators.min(8), Validators.max(25)]],
        phone:this.fb.array([]),
        address:this.fb.group({
          country:['']
        })
      })

      

      // this.regForm = new FormGroup({
      //   name:new FormControl('',[Validators.required, Validators.pattern('[a-z]{3,10}')]),
      //   email:new FormControl('',[Validators.required, Validators.email]),
      //   password:new FormControl('',[Validators.required,Validators.min(8), Validators.max(25)])
      // });
   }
  ngOnInit(): void {
  }

}
