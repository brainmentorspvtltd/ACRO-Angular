import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";

@Injectable({
    providedIn:'root'
})
export class AuthGuard implements CanActivate{
    isAuth:boolean;
    constructor(private route :Router){
        this.isAuth = true;
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
        console.log('Auth Guard Runs....');
        if(this.isAuth){
            return true;
        }
        else{
            return this.route.navigate(['/']); // Send to the Home Page
        }
    }

}