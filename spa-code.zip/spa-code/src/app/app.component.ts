import { Component, OnInit ,isDevMode } from '@angular/core';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  currentEnv:string = "";
  ngOnInit(): void {
      if(isDevMode()){
          this.currentEnv = "Development Env "+environment.URL+" "+environment.apiKey;
      }
      else{
        this.currentEnv = "Production Env "+environment.URL+" "+environment.apiKey;
      }
  }
  title = 'simple-spa';


}
