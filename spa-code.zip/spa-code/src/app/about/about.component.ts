import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit, OnDestroy {
  declare ename:string;
  declare company:string;
  msg:string = "";

  country:string[] = ["India", "Srilanka", "Nepal", "China"];
  constructor(private route:ActivatedRoute) { }
  ngOnDestroy(): void {
    console.log("About Destroy Call");
  }

  register(form:NgForm):void{
      console.log('Form Submitted ', form);
      if(form.invalid){
          this.msg = "INvalid Form";
      }
      else{
        this.msg = "Valid Form";
      }
  }

  group(q:any):void{
    console.log(q.invalid);
    console.log(q.control.controls.email);
  }

  ngOnInit(): void {
    const obj = this.route.snapshot.queryParams;
    console.log('Query Param is ',obj);
    this.ename = obj['name'];
    this.company = obj['company'];

    console.log("About Init Call");
  }



}
