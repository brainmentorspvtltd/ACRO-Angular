export const environment = {
  production: true,
  apiKey:'Prod keys',
  URL:'http://abcd.com/login'
};
