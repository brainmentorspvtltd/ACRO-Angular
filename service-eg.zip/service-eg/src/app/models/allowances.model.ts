export class AllowanceModel{
    declare bs:number;
    declare hra:number;
    declare da:number;
    declare ta:number;
    declare pf:number;
    declare ma:number;
    declare tax : number;
    declare gs:number;
    declare ns:number;
    // constructor(bs:number, hra:number, da:number, ta:number, pf:number, ma:number, tax:number, gs:number, ns:number){
    //     this.bs = bs;
    //     this.hra = hra;
    //     this.da= da;
    //     this.ta = ta;
    //     this.ma = ma;
    //     this.pf = pf;
    //     this.tax = tax;
    //     this.gs = gs;
    //     this.ns = ns;
    // }
}