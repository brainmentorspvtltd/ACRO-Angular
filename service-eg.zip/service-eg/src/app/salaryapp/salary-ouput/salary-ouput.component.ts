import { Component, Input, OnInit } from '@angular/core';
import { AllowanceModel } from 'src/app/models/allowances.model';
import { AllowancesService } from 'src/app/services/allowances.service';

@Component({
  selector: 'app-salary-ouput',
  templateUrl: './salary-ouput.component.html',
  styleUrls: ['./salary-ouput.component.css']
})
export class SalaryOuputComponent implements OnInit {
  @Input()
  bs:number =0;

  declare allowanceObject: AllowanceModel;
  
  // Call the Service
  //serviceObject:AllowancesService = new AllowancesService(0);

  constructor(private serviceObject: AllowancesService) {
    // Listener  
    this.serviceObject.allowancesEvent.subscribe((allowanceModel:AllowanceModel)=>{
        console.log('Rec Allowances model Object ', allowanceModel);
        this.allowanceObject = allowanceModel;
      })

   }

  allowances():void{
     console.log('HRA is ', this.serviceObject.hra());
     console.log('Da is ', this.serviceObject.da());

  }

  // tax():number{
  //   return  this.computeGS() * 0.10;
  // }
  // ns(){
  //   return this.computeGS() - this.tax() - this.bs * 0.05;
  // }
  // computeGS() :number{
  //   /*
  //   <p>Hra {{bs * 0.50}}</p>
  //   <p>DA {{bs * 0.20}}</p>
  //   <p>TA {{bs * 0.10}}</p>
  //   <p>MA {{bs * 0.25}}</p>
  //   */
  //     return this.bs  + (this.bs * 0.50) + (this.bs * 0.20) + (this.bs * 0.10) + (this.bs * 0.25);
  // }
  ngOnInit(): void {
  }

}
