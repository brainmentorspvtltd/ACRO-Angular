import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalaryOuputComponent } from './salary-ouput.component';

describe('SalaryOuputComponent', () => {
  let component: SalaryOuputComponent;
  let fixture: ComponentFixture<SalaryOuputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalaryOuputComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SalaryOuputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
