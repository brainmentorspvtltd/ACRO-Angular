import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AllowanceModel } from 'src/app/models/allowances.model';
import { AllowancesService } from 'src/app/services/allowances.service';

@Component({
  selector: 'app-salary-input',
  templateUrl: './salary-input.component.html',
  styleUrls: ['./salary-input.component.css']
})
export class SalaryInputComponent implements OnInit {
  // Call the Service
 // serviceObject:AllowancesService = new AllowancesService(0);
  @Output()
  onSalaryChange:EventEmitter<number> = new EventEmitter<number>();
  constructor(private serviceObject: AllowancesService) { }
  computeIt(event:any, basicSalary:string):void{
    console.log('Compute It call ', basicSalary);
    let bs:number = parseInt(basicSalary);
    //this.serviceObject.basicSalary = bs; // Set the basic salary in Service
    //let allowanceModel:AllowanceModel = new AllowanceModel(); 
    //let allowanceModel:AllowanceModel = this.serviceObject.computeAllAllowances(bs); // Service Fn Call
   // allowanceModel.bs = bs;
   //this.serviceObject.allowancesEvent.emit(allowanceModel);
    this.serviceObject.allowancesEvent.emit(this.serviceObject.computeAllAllowances(bs)); // Notify the Listeners
    
    // this.onSalaryChange.emit(bs); // Call the parent fn 
  }
  ngOnInit(): void {
  }

}
