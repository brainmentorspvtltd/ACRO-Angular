import { EventEmitter, Injectable } from "@angular/core";
import { AllowanceModel } from "../models/allowances.model";

// Service is Just a TS Class
@Injectable()
export class AllowancesService{
    allowancesEvent:EventEmitter<AllowanceModel> = new EventEmitter<AllowanceModel>();
    declare basicSalary:number;
    allowanceObject: AllowanceModel = new AllowanceModel();
    // constructor(basicSalary:number){
    //         this.basicSalary = basicSalary;

    // }
    computeAllAllowances(basicSalary:number):AllowanceModel{
        this.basicSalary = basicSalary;
        this.hra();
        this.da();
        this.ta();
        this.ma();
        
        this.pf();
        this.gs();
        this.tax();
        this.ns();
        return this.allowanceObject;
    }
    hra(){
        this.allowanceObject.hra =  this.basicSalary * 0.50;
        return this.allowanceObject.hra;
    }
    da(){
        this.allowanceObject.da = this.basicSalary * 0.20;
        return this.allowanceObject.da;
    }
    ta(){
        this.allowanceObject.ta  = this.basicSalary * 0.10;
        return this.allowanceObject.ta;
    }
    ma(){
        this.allowanceObject.ma = this.basicSalary * 0.25;
        return this.allowanceObject.ma;
    }
    pf(){
        this.allowanceObject.pf = this.basicSalary * 0.05;
        return this.allowanceObject.pf;
    }
    gs(){
        this.allowanceObject.gs = this.basicSalary + this.hra() + this.da() + this.ma() + this.ta();
        return this.allowanceObject.gs;
    }
    tax(){
        this.allowanceObject.tax = this.gs() * 0.10;
        return this.allowanceObject.tax;
    }
    ns(){
        this.allowanceObject.ns= this.gs() - this.pf() - this.tax();
        return this.allowanceObject.ns;
    }
}