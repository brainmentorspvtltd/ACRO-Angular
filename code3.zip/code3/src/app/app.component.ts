import { Component, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { map } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { ApiClientService } from './api-client.service';
import { User } from './models/user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges, OnDestroy {
  title = 'http-demo';
  users:User[]=[];
  obs:Observable<User[]> ;  
  constructor(private apiClient:ApiClientService){
    this.obs = this.getAllUsers();
  }
  ngOnDestroy(): void {
    // UnSubscribe, Event UnBind, LocalStorage clear
    console.log('Destroy...');
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log('I/O Has Some Changes....');
  }
  ngDoCheck(){
    console.log('Do Check....');
  }
  ngOnInit(): void {
    console.log('Component Initalize ....');
    // Backend call
    // Subscribe
    // Event Bind
    // FireBase 
  }
  

  

  getAllUsers():Observable<User[]>{
    // console.log('app:getAllUsers Component I am Here');
    // console.warn('app:getAllUsers Component I am Here');
    // console.info('app:getAllUsers Component I am Here');
    // console.error('app:getAllUsers Component I am Here');
    // const names:string[]  = ["Amit","ram","shyam"];
    // console.table(names);
    return this.apiClient.getAllUsers();
  }
  
  

  postUser():void{
    const user:User = {
      name:'Amit',email:'amit@yahoo.com', id:1001, phone:'2222'
    };
    this.apiClient.postUsers(user);
  }

  makeParallelCalls(){
    this.apiClient.makeParallelCalls();
  }

  makeSeqCalls(){
    this.apiClient.makeSeqCalls();
  }

  getMultiUsers():void{
      const obs:Observable<User[]> = this.apiClient.getUserMulti();
      // A Users 
      const obs2 = obs.pipe(map(user=>user.filter(user=>user.name.includes("a"))));

      const obs3 = obs.pipe(map(user=>user.filter(user=>user.name.startsWith("M"))));
      obs2.subscribe({
        next:(data)=>console.log('Data OBS2 ', data),
        error:(err)=>console.log('Error is ',err)
      });
      obs3.subscribe({
        next:(data)=>console.log('Data OBS3 ', data),
        error:(err)=>console.log('Error is ',err)
      })
    }

  getUsers():void{
    const obs:Observable<User[]> = this.apiClient.getUsers();
    obs.subscribe({
      next:(users)=>{
          this.users = users;
          console.log('All the User Data is ', this.users);
      },
      error:(err)=>{
          console.log('Error During Ajax Call ', err);
      },
      complete:()=>{
        console.log('Completed....');
      }
    })
  }
}
