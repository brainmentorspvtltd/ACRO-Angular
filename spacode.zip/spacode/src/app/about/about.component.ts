import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit, OnDestroy {
  declare name:string;
  declare company:string;
  constructor(private route:ActivatedRoute) { }
  ngOnDestroy(): void {
    console.log("About Destroy Call");
  }

  ngOnInit(): void {
    const obj = this.route.snapshot.queryParams;
    console.log('Query Param is ',obj);
    this.name = obj['name'];
    this.company = obj['company'];

    console.log("About Init Call");
  }



}
