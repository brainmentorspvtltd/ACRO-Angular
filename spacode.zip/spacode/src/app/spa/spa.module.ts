import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { ShopComponent } from '../shop/shop.component';
import { AboutComponent } from '../about/about.component';
import { NewsComponent } from '../news/news.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';

// Maintain Routes (Mapping)
const applicationRoutes :Routes = [
  {path:'', component : HomeComponent},
  {path:'products/:id/:price', component: ShopComponent, pathMatch:'full'},
  {path:'products', component: ShopComponent},
  {path:'about', component:AboutComponent},
  {path:'news', component:NewsComponent},
  {path:'page-not-found',component:PageNotFoundComponent},
  {path:'**', redirectTo:'page-not-found'}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule, RouterModule.forRoot(applicationRoutes)
  ],
  exports:[RouterModule]
})
export class SpaModule { }
