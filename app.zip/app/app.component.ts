import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
 
})
export class AppComponent {
  fruits :string [] = ["Apple", "Orange", "Mango"];
  title = 'My First Application...';
  firstName = "Amit";
  lastName = "Srivastava";
  isDisabled:boolean = true;
  myClass:string = "green";
  count:number =0;
  message:string = "";
  addressValue:string = "";
  remarks:string = "";
  plusIt():void{
      this.count++;
  }
  takeInput(event:any):void{
    console.log("Take Input call.... ", event.target.value);
    this.message = event.target.value;
  }
  save(city:string, country:string):void{
    this.addressValue = `City ${city} and Country ${country}`;
  }
}
