import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SalaryappComponent } from './salaryapp/salaryapp.component';
import { SalaryInputComponent } from './salaryapp/salary-input/salary-input.component';
import { SalaryOuputComponent } from './salaryapp/salary-ouput/salary-ouput.component';


@NgModule({
  declarations: [
    AppComponent,
    SalaryappComponent,
    SalaryInputComponent,
    SalaryOuputComponent
    
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
