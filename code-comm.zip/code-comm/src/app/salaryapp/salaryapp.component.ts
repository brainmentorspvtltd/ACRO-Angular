import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salaryapp',
  templateUrl: './salaryapp.component.html',
  styleUrls: ['./salaryapp.component.css']
})
export class SalaryappComponent implements OnInit {
  basicSalary:number;
  getDataFromChild(bs:number):void{
    console.log('Call From the Child Component ', bs);
    this.basicSalary = bs;
  }
  constructor() {
    this.basicSalary = 0;
   }

  ngOnInit(): void {
  }

}
