import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-salary-input',
  templateUrl: './salary-input.component.html',
  styleUrls: ['./salary-input.component.css']
})
export class SalaryInputComponent implements OnInit {
  @Output()
  onSalaryChange:EventEmitter<number> = new EventEmitter<number>();
  constructor() { }
  computeIt(event:any, basicSalary:string):void{
    console.log('Compute It call ', basicSalary);
    let bs:number = parseInt(basicSalary);
    this.onSalaryChange.emit(bs); // Call the parent fn 
  }
  ngOnInit(): void {
  }

}
