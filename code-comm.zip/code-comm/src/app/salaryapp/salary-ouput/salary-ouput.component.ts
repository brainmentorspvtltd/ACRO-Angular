import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-salary-ouput',
  templateUrl: './salary-ouput.component.html',
  styleUrls: ['./salary-ouput.component.css']
})
export class SalaryOuputComponent implements OnInit {
  @Input()
  bs:number =0;
  constructor() { }
  tax():number{
    return  this.computeGS() * 0.10;
  }
  ns(){
    return this.computeGS() - this.tax() - this.bs * 0.05;
  }
  computeGS() :number{
    /*
    <p>Hra {{bs * 0.50}}</p>
    <p>DA {{bs * 0.20}}</p>
    <p>TA {{bs * 0.10}}</p>
    <p>MA {{bs * 0.25}}</p>
    */
      return this.bs  + (this.bs * 0.50) + (this.bs * 0.20) + (this.bs * 0.10) + (this.bs * 0.25);
  }
  ngOnInit(): void {
  }

}
