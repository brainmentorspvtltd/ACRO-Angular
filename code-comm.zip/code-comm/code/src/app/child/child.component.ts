import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  x:number =100;
  title:string = 'Hello I am Child';
  constructor() { }

  ngOnInit(): void {
  }
  show():void{
    console.log('I am the Show');
  }
  disp(y:number):number{
    return this.x * 100 * y;
  }

}
