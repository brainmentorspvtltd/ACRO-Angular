import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ChildComponent } from './child/child.component';
import { Child2Component } from './child2/child2.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'secondway';
  @ViewChild(ChildComponent)  // Get the Child Component Reference (Reference Way)
  declare childObject:ChildComponent ;

  @ViewChildren(Child2Component)
  declare childList:QueryList<Child2Component>;

  showIt(event:any):void{
    console.log('Child is ', this.childObject);
    this.childObject.show();
    this.title = this.childObject.x+" "+this.childObject.title + this.childObject.disp(5);
  }

  takeName(event:any):void{
      this.title = event.target.value;
      this.childList.forEach(child=>{
        console.log('My Name is ',child.takeInput(this.title));
      });
  }
}
