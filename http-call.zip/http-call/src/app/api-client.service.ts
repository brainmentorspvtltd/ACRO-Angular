import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, shareReplay, forkJoin, switchMap } from 'rxjs';

import { User } from './models/user.model';

@Injectable({
  providedIn: 'root'
})
export class ApiClientService {
  name:string = "Amit";
  readonly URL:string = "https://jsonplaceholder.typicode.com/users";

  constructor(private http:HttpClient) { }


  makeParallelCalls():void{
    const obs = forkJoin(
      [this.http.get(this.URL),
      this.http.get("https://jsonplaceholder.typicode.com/posts")]
    );
    obs.subscribe({
      next:(values)=>console.log('All values ', values),
      error:(err)=>console.log('Error is ', err)
    })
     
      
  }

   makeSeqCalls(){
    // First Call
      this.http.get<User[]>(this.URL).pipe(switchMap((users, index)=>{
          let id = users[0].id;
          let idx:any = index;
          // this is a second call , after first call result
          return this.http.get('https://jsonplaceholder.typicode.com/posts?id='+id+'&idx='+idx);
      })).subscribe({
        next:(data)=>{
            console.log('Seq Call Data ', data);
        },
        error:(err)=>{
          console.log('Error in Seq call ', err);
        }
      })
   } 

  getUserMulti():Observable<User[]>{
    // Admin 
    console.log('Multi Call ');
    return this.http.get<User[]>(this.URL).pipe(shareReplay());

    // Guest

    // Staff


  }

  // Read, Search, Sort
  getUsers():Observable<User[]>{
    // Query String Parameters
    const queryParams = new HttpParams().set('name','Amit')
   .set('pincode',"110007");
   // Setting Request Headers
   const headers = new HttpHeaders().set("X-Custom-Header","MYHEADERVALUE");
   
    return this.http.get<User[]>(this.URL, {params:queryParams, headers:headers});
  }
  // Create
  postUsers(user:User):void{
      this.http.post(this.URL, user).subscribe({
        next:(data)=>console.log('Data Post ', data),
        error:(err)=>console.log('Post Error ', err)
      });
  }

  // Put - Updation (And Fully Replace the Resource)
  updateUser(user:User):void{
    const headers = new HttpHeaders().set("Content-Type","application/json");
    this.http.put(this.URL, user, {headers:headers}).subscribe({
      next: (data)=>console.log('Update Done ', data),
      error:(err)=>console.log('Error is ', err)
    })
  }

  // Patch - Single Property of a resource update.
  patchUser(name:string):void{
      this.http.patch(this.URL ,{
        "name":name
      }).subscribe(
        {
          next: (data)=>console.log('Patch Done ', data),
          error:(err)=>console.log('Error is ', err)
        }
      )
  }

  deleteUser(user:User){
      this.http.delete(URL+"/"+user.id).subscribe({
        next: (data)=>console.log('Delete Done ', data),
        error:(err)=>console.log('Error is ', err)
      })
  }
}
