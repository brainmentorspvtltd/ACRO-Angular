export interface User{
    name:string;
    id:number;
    email:string;
    phone:string;
}