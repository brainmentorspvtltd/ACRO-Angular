import { Injectable } from "@angular/core";
import { PaymentService } from "src/app/payment/payment.service";

// @Injectable({
//     providedIn:'root'
// })
@Injectable()
export class OrderService{

    constructor(private paymentService:PaymentService){

    }

}