import { Component } from '@angular/core';
import { 
  from, 
  fromEvent, 
  interval,
   map, 
   Observable, 
   Observer, 
   of, 
   range, 
   Subscription, 
   take, filter, skip, shareReplay
  } 
  from 'rxjs';
import {fromFetch} from "rxjs/fetch"


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'reactive-demo';
  promiseData:string = "";
  obsData:string = "";
  count:number = 0;
  count2:number = 0;

  usingOf(){
    //let obs: Observable<number> = of(1,2,3,4,5,6,7,8,9,10);
    let obs: Observable<string> = from(['ram','shyam', 'sohan', 'mohan']);
    return obs;
  }  

  usingFromFetch(){
    const URL = "https://jsonplaceholder.typicode.com/users";
    fromFetch(URL).subscribe({
      next:(response)=>{
        console.log('Response ', response);
      },
       error:(err)=>{
        console.log('Error is ', err);
      },
      complete:()=>{
        console.log('Completed....');
      }
    });
  }

  usingFromEvent(){
    const button:HTMLElement|null = document.getElementById('okbt');
    const obs = fromEvent(button!,'click'); // addEventListener
    obs.subscribe(event=>{
        console.log('Button Click ', event);
    })
  }

  getObs():Observable<number>{
    const obs =interval(2000);
      // const obs = new Observable<string>((observer)=>{
      //   setInterval(()=>{
      //       this.count ++;
      //       observer.next("I am the Observer Next Data "+this.count);
      //   },1000);
      // })
      return obs;
  }

  usingRange(){
    const numbers = range(100,50);
    numbers.subscribe(num=>{
      console.log('Num is ', num);
    })
  }

  myFetch():Observable<any>{
    const URL = "https://jsonplaceholder.typicode.com/users";
    const obs= new Observable((obs:Observer<any>)=>{
        // API CALl ES6 Fetch (Promise Based)
        const promise = fetch(URL);
        promise.then(response=>{
          response.json().then(data=>{
            obs.next(data);
            obs.complete();
          }).catch(err=>{
            obs.error(err);
          }).catch(err=>{
            obs.error(err);
          })
        })
    });
    return obs;
  }

  usingCreate(){
    let count = 1;
    const e  = Observable.create((obs:Observer<number>) =>{
      setInterval(()=>{
        obs.next(count);
        count++;
      }, 1000);
    });
    e.subscribe((data:number)=>console.log('Create ',data));
  }

  usingOperators(){
   const stream:Observable<number> =  interval(1000);
    stream.pipe(
      skip(10),
      
      filter((data:number)=>data%2==0),
      take(5),
      map((data:number)=>data * data) ).subscribe(result=>{
      console.log('*** MAP ', result);
    })
  }

  consumeObs():void{
    this.usingOperators();
    // const obs = this.myFetch();
    // obs.subscribe({
    //   next:data=>{
    //     console.log('************* Data Comes ', data);
    //   }, error : err=>{
    //     console.log('*********** Error Comes ', err);
    //   },
    //   complete:()=>{
    //     console.log('************** Completed.....');
    //   }
    // })
    // this.usingCreate();
    // this.usingFromFetch();
    // this.usingFromEvent();
    // this.usingRange();
    // this.usingOf().subscribe(data=>{
    //   console.log('Consuming of .... ', data);
    //   this.obsData = data.toString()
    // }
    //   );
    
    const sub:Subscription = this.getObs().subscribe(data=>{
      document.body.style.backgroundColor = `rgb(${Math.random()*255},${Math.random()*255},${Math.random()*255})`
      this.obsData = data.toString();
    });
    setTimeout(()=>{
      console.log('Unsubscribe...');
        sub.unsubscribe();
    }, 9000);
  }

  consumePromise():void{
    this.getPromise().then(data=>{

        this.promiseData = data;
    }).catch(err=>this.promiseData = err);
  }

  getPromise(): Promise<string>{
    const promise = new Promise<string>((resolve, reject)=>{
        setInterval(()=>{
          this.count2++;
          resolve("Success Result "+this.count2);
        }, 1000);
    });
    return promise;
  }
}
