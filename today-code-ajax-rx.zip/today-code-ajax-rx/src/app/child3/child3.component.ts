import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css']
})
export class Child3Component implements OnInit {
  myData:string;
  constructor(private commonService:CommonService) {
    this.myData = '';
   }
  subIt():void{
      this.commonService.subject.subscribe(data=>{
        console.log('Subscribe it .... ', data);
          this.myData = `X is ${data.x} and Y is ${data.y}`;
      })
  }
  ngOnInit(): void {
  }

}
