import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { ComplexModel } from './models/complex.model';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  subject:BehaviorSubject<ComplexModel> = new BehaviorSubject<ComplexModel>(new ComplexModel());
  //subject:BehaviorSubject<number> = new BehaviorSubject<number>(0);
  //subject:Subject<number> = new Subject<number>();
  count:number ;
  plusIt():void{
    this.count++;
    const obj: ComplexModel = new ComplexModel();
    obj.x  = this.count;
    obj.y = this.count * 2;
    this.subject.next(obj);
  }

  constructor() {
    this.count = 0;
   }
}
