import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-child4',
  templateUrl: './child4.component.html',
  styleUrls: ['./child4.component.css']
})
export class Child4Component implements OnInit {
  countValue:number ;
  constructor(private commonService:CommonService) { 
    this.countValue = 0;
    commonService.subject.subscribe({
      next:data=>this.countValue = data.x + data.y,
      error:err=>console.log('Error is ', err),
      complete:()=>console.log('Completed.... ')
    });

  }

  ngOnInit(): void {
  }

}
