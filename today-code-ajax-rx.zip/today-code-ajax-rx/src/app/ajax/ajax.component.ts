import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajax',
  templateUrl: './ajax.component.html',
  styleUrls: ['./ajax.component.css']
})
export class AjaxComponent implements OnInit {
  users:any[] = [];
  constructor(private http:HttpClient) {
    console.log('I am a Constructor Call');
   }

   ajaxCall(){
    const URL = "https://jsonplaceholder.typicode.com/users";
    let obs = this.http.get<any[]>(URL);
    obs.subscribe({
      next:(data)=>{
       
        this.users = data;
        console.log('Data is ', this.users);
      },
      error: (err)=>{
        console.log('Http Error ', err);
      },
      complete:()=>{
        console.log('Completed... ');
      }

    })
   }

  ngOnInit(): void {
    console.log('I am a NgOnInit call...');
    this.ajaxCall();
  }

}
