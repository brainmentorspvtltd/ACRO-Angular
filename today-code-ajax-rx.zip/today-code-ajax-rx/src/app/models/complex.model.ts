export class ComplexModel{
    declare x:number;
    declare y :number;
    constructor(){
        this.x = 0;
        this.y = 0;
    }
}