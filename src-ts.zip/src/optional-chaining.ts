const person = {
    id:1001, 
    name:'Ram',
    job:{designation : 'Developer', exp: 5},
    address:{city:'delhi', country:'India', state : null}

}

const personStr = JSON.stringify(person);

const obj4 = JSON.parse(personStr);
console.log('OPt Chain ',obj4?.city?.length);

console.log(person.address.city);
// console.log(person.address.state?.length);

type MBAStudent = {
    rollno:number, 
    name:string,
    address?:{
        state:string, city:string
    }
}
var e:MBAStudent = {rollno:1001, name:'Ram'};
console.log(e.address?.state);
console.log(e);