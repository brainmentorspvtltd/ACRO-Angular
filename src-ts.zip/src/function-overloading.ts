function adder(a:number, b:number):number;
function adder(a:string, b:string):string;
function adder(a:string, b:number):string;
function adder(a:number|string, b:string|number): number | string{
   if(typeof a ==='string' || typeof b ==='string'){
    return a.toString() + b.toString();
   }
    return  a + b;
   
   
    
}

function show(d:number, a?:number, b?:number):void{
    console.log(d, a, b);
}
show(10);
show(10,20);
show(10,20,30);
//show(10,undefined,90);

//let c:number = adder(10,20);
//let c:string = adder("10",2);
let c:string= adder("100","200");
console.log(c);

