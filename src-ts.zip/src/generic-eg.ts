class Stack<T>{
    arr : T[] ;
    //static w:T;
    constructor(){
        this.arr = [];
    }
    push(data:T):number{
        this.arr.push(data);
        return this.arr.length;
    }
}
let obj2:Stack<string> = new Stack<string>();
obj2.push("Amit");
obj2.push("Ram");
console.log(obj2.arr);

let obj3:Stack<number> =new Stack<number>();
obj3.push(100);
obj3.push(200);
obj3.push(300);
console.log(obj3);
