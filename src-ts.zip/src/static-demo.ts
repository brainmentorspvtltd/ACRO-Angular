class Customer{
    declare id:number; // Instance Variables (Object create) (Lazy)
    declare name:string;
    declare balance:number;
    static count:number // During Class Load... (Eager)
   // bonus:number;
    constructor(id:number, name:string, balance:number){
        console.log(" Cons call "+name);
        this.id =id;
        this.name = name;
        this.balance = balance;
       Customer.count++;
        //console.log('Count is ', Customer.count);
    }

    static show():void{ // Eager
        console.log("I am a Static Show...");
    }

    static {
        Customer.count = 0;
        console.log("I Run When class is loaded in the Memory...");
    }

}
console.log('Before Calling Objects.......');
let ram : Customer = new Customer(1001, "ram",9999);
let ramesh : Customer = new Customer(1002, "ramesh",2999);
let tim2 : Customer = new Customer(1003, "tim",4999);
//console.log(ram);
console.log('Total Customers ', Customer.count);
Customer.show(); // ClassName.staticThing


