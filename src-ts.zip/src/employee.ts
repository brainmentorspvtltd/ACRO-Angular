 class Employee{
    
    private name:string; // Instance Members
    protected id:number;
    public salary:number; // default scope is public
    public readonly companyName:string;  // TS 2.0
    constructor(name:string, id:number, salary:number){
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.companyName   = "Brain Mentors"

    }
    // ShortHand Constructor Way
    // constructor(private name:string, protected _id:number, public salary:number, public bonus:number=1000){

    // }
    printEmp():void{
        console.log(`Id ${this.id} Name ${this.name} Salary ${this.salary}`);
    }
    // set id(i:number){
    //     this._id =i;
    // }
    // get id():number{
    //     return this._id;
    // }
}
// Wrap in a object ,so we need to destructure it during import
export const MAX =100;
export function show(){

}
// not wrapped in Object
export default Employee;
