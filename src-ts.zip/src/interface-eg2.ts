// function greet(person:{name:string, age:number}){
//     return "Hi "+person.name;
// }
// type Person = {
//     name:string, age:number
// }
// function greet(person:Person){
//     return "Hi "+person.name;
// }
interface Person{
    name:string, age:number, salary?:number, city:string
}
// Inteface as Argument
function greet(person:Person){
    return "HI "+person.name +" "+person.city+" "+person.salary;
}
console.log(greet({name:'Ram', age:21, city:'Delhi'}));

// Interface as a Type
var obj:Person = {name:'Shyam' , age:22, city:'Mumbai'};


interface Student extends Person{
    course:string, duration:number;
}

var tom:Student = {name:'Tom', age:22, city:'Delhi', course:'JS', duration:1};


type IPerson = {
    name:string, age:number
}

type ITStudent = IPerson & {
    course:string, duration:number
}

var tim : ITStudent = {course:'Ts', duration:2, name:'Ramesh', age:23};