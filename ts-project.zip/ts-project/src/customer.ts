// class Customer{
//     id:number;
//     name:string;

// 	constructor() {
// 	}
//     private _balance: number;
//     public get balance(): number {
//         return this._balance;
//     }
//     public set balance(value: number) {
//         this._balance = value;
//     }
    
// }