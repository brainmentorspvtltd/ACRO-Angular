var arr:string[] = ["Amit","Ram","Shyam"]; // Type Annotation
var arr2 = ["Ram","Amit"]; // Type Inference

// Tuples - Mix the Types (Fixed Array (Types are Fixed , Where Length is Not))
var records:[string, number] = ["Amit", 1001]; // Type Annotations
console.log(records[0]);
records.push(1002,1000,1003,"Ramesh", "Shyam") ; // Dynamic in Size
console.log(records);
//records[0] = 1111;
console.log(records[1]);
//console.log(records[2]); // During Access By INdex , that is makes Fixed Length
var records2 = [1001, "Amit"]; // Type Inference
records[0] = "Ram";

const userInfo = {
    name:'Ram', email:'ram@yahoo.com', role:[10, "Admin","A"]
}
console.log(userInfo.name);
console.log(userInfo.email);
console.log(userInfo.role[0], userInfo.role[1], userInfo.role[2]);




