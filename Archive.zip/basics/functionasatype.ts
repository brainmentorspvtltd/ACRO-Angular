type fnType = (x:number, y:number)=>number;
function add(x:number, y:number):number{
    return x + y;
}
function printIt(x:number):number{
    return x*10;
}
const f3:fnType = add;
const f4:fnType = printIt;
const fn2 : (x:number, y:number)=>number = (a:number, b:number)=>a+b; // One time consume

console.log(f3(10,20));
console.log(f4(1000,22));