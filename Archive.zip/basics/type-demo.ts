type Person = {
    id:number, name:string
}
var obj:Person = {id:1001, name:'Ram'};
var obj2:Person ={id:1002, name:'Ramesh'}; 
console.log(obj.id);
console.log(obj.name);
console.log(obj2);
showPerson(obj2);
var obj3 = {id:111, name:'ABcd', salary:8888};
showPerson(obj3);
function showPerson(person: Person):void{
    console.log(person.id,person.name);
}
