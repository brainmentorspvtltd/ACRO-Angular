let x:unknown;
let p : unknown = x;
x=100;
x =true;
x = "Amit";
//x = [10,20,30];
var t:any = x;

//var z:string  = x;

let y:any;
y = 200;
y = false;
y = "Ram";
console.log(typeof y);
//y = [100,200,300];
var e:string = y; 