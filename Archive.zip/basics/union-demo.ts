var x:number|string ;
x = "Amit";
x = 10;
console.log(add(10,20));
console.log(add("ram","sharma"));
function add(x:number|string, y:number|string): string|number{
    if(typeof x ==='number' && typeof y ==='number'){
        return x + y;
    }
    else{
        return x.toString() + y.toString();
    }
}