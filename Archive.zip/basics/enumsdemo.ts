// const UP = 1;
// const DOWN = 2;
// const LEFT = 3;
// const RIGHT = 4;
enum Directions {
    UP=10, DOWN, LEFT, RIGHT
}
function giveResult(){
    return 20;
}
enum ComputedEnum{
    AGREE = 10 + 2,
    RESULT = giveResult()
}
enum Mix{
    YES = "yes",
    NO = 0,
    
}
console.log(Directions.UP);
console.log(Directions.DOWN);
let KEY_PRESS:Directions ;
if(10>2){
    KEY_PRESS = Directions.UP;
}
else{
    KEY_PRESS = Directions.DOWN;
}
switch(KEY_PRESS){
    case Directions.UP:
        console.log("Up Key Press");
        break;
        case Directions.DOWN:
            console.log("Up Key Press");
            break;
}