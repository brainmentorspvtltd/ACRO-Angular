function giveError(message:string, code:number):never{
   // throw {message: message, errorCode:code};
   throw new Error(message + "Error Code "+code);
}
giveError("Some Error ", 500);