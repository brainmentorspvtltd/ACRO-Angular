// function callMe(callBackFn:any){
//     callBackFn();
// }
// function callMe2(callBackFn:unknown){
//     callBackFn();
// }
function callMe(callBackFn:unknown){
    if(typeof callBackFn==='function'){
    callBackFn();
    }
    else{
        console.log("i am not a function ", callBackFn);
    }
}
callMe(1);
callMe("Ram");
callMe(()=>console.log("I am the Fn "));
