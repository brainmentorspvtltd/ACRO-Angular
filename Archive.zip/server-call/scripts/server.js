var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
window.addEventListener('load', showData);
function showData() {
    return __awaiter(this, void 0, void 0, function* () {
        const comments = yield doAjax();
        console.log('All Comments is ', comments);
        comments.forEach((comment) => {
            const pTag = document.createElement('p');
            pTag.innerText = comment.email + " " + comment.name + " " + comment.body;
            document.body.appendChild(pTag);
        });
    });
}
function doAjax() {
    return __awaiter(this, void 0, void 0, function* () {
        const URL = "https://jsonplaceholder.typicode.com/comments";
        //const pr = fetch(URL);
        let comments = [];
        try {
            const response = yield fetch(URL);
            console.log('response is ', response);
            // const comments:Comments[] = await response.json();
            const allComments = yield response.json();
            comments = allComments.map(comment => {
                let c = {
                    name: comment.name, email: comment.email, body: comment.body
                };
                return c;
            });
            console.log('Comments are ', comments);
        }
        catch (err) {
            console.log('Error is ', err);
        }
        return comments;
        // pr.then((res:Response)=>{
        //     res.json().t
        // })
    });
}
