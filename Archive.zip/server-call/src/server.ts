window.addEventListener('load', showData);
async function showData(){
    const comments:Comments[] = await doAjax();
    console.log('All Comments is ', comments);
    comments.forEach((comment:Comments)=>{
        const pTag: HTMLParagraphElement = document.createElement('p');
        pTag.innerText = comment.email+ " "+comment.name+" "+comment.body;
        document.body.appendChild(pTag);
    });

}
async function doAjax(){
    const URL:string = "https://jsonplaceholder.typicode.com/comments";
    //const pr = fetch(URL);
    let comments:Comments [] = [];
    try{
    const response = await fetch(URL);
    console.log('response is ', response);
    // const comments:Comments[] = await response.json();
    const allComments:any[] = await response.json();
    comments = allComments.map(comment=>{
        let c:Comments = {
            name:comment.name, email:comment.email ,body:comment.body 
        }
        return c;
    })
    console.log('Comments are ', comments);
    
    }
    catch(err){
        console.log('Error is ', err);
    }
    return comments;
    // pr.then((res:Response)=>{
    //     res.json().t
    // })
}
type Comments = {
    email:string, body:string, name:string
}